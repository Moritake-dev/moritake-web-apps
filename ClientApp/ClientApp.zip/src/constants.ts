export class Constants {
    // Api related URIs

    // Fetches login
    public static idpAuthority = "https://localhost:44358";
    // Fetches Data
    public static apiRoot = "https://localhost:44358";

    // Client related URIs
    public static clientId = "mgSolutions";
    public static clientRoot = "http://localhost:4200";
}