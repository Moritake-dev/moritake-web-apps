import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-information-board',
  templateUrl: './information-board.component.html',
  styleUrls: ['./information-board.component.css']
})
export class InformationBoardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
